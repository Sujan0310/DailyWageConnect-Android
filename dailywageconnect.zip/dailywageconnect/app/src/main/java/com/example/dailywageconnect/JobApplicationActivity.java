package com.example.dailywageconnect;

public class JobApplicationActivity {
}
